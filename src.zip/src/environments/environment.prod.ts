export const environment = {
  production: true,
  name:"",
   //user
   login_Url : "http://35.202.22.39:8080/user/login",
   signup_Url : "http://35.202.22.39:8080/user/add",
 //book
   bookList_Url : "http://35.202.22.39:8081/books/list",
   bookAdd_Url : "http://35.202.22.39:8081/books/add",
   bookQuantity_Url : "http://35.202.22.39:8081/books/updatequantity",
 
   //order
   orderAdd_Url : "http://35.202.22.39:8082/orders/cart/add",
   orderList_Url : "http://35.202.22.39:8082/orders/cart/list",
   orderDelete_Url : "http://35.202.22.39:8082/orders/cart/delete",
   orderPay_Url : "http://35.202.22.39:8082/orders/cart/pay",
   orderMyoders_Url : "http://35.202.22.39:8082/orders/myorders",
   orderAll_Url : "http://35.202.22.39:8082/orders/all",
   orderUpdate_Url : "http://35.202.22.39:8082/orders/update",
 
};
