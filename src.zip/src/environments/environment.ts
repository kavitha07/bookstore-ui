// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  name:"(DEV)",
  //user
  login_Url : "http://35.202.22.39:8080/user/login",
  signup_Url : "http://35.202.22.39:8080/user/add",
//book
  bookList_Url : "http://35.202.22.39:8081/books/list",
  bookAdd_Url : "http://35.202.22.39:8081/books/add",
  bookQuantity_Url : "http://35.202.22.39:8081/books/updatequantity",

  //order
  orderAdd_Url : "http://35.202.22.39:8082/orders/cart/add",
  orderList_Url : "http://35.202.22.39:8082/orders/cart/list",
  orderDelete_Url : "http://35.202.22.39:8082/orders/cart/delete",
  orderPay_Url : "http://35.202.22.39:8082/orders/cart/pay",
  orderMyoders_Url : "http://35.202.22.39:8082/orders/myorders",
  orderAll_Url : "http://35.202.22.39:8082/orders/all",
  orderUpdate_Url : "http://35.202.22.39:8082/orders/update",

   



};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
