import { Injectable } from "@angular/core";

@Injectable()
export class Globals {

    private BOOK_IP_ADDRESS ='35.202.22.39';
    private USER_PORT ='8080';
    private BOOK_PORT ='8081';
    private ORDER_PORT ='8082';

    private USER_SERVICE_URL='http://'+this.BOOK_IP_ADDRESS+':'+this.USER_PORT;
    private BOOK_SERVICE_URL='http://'+this.BOOK_IP_ADDRESS+':'+this.BOOK_PORT;
    private ORDER_SERVICE_URL='http://'+this.BOOK_IP_ADDRESS+':'+this.ORDER_PORT;

//http://35.202.22.39:8080/user
    private LOGIN_URL= this.USER_SERVICE_URL+'/user/login';
    private SIGNUP_URL= this.USER_SERVICE_URL+'/user/add';

    private USER_CHECK_URL= this.USER_SERVICE_URL+'/user/login';
//http://35.202.22.39:8081/books
    private LIST_BOOKS_URL= this.BOOK_SERVICE_URL+'/books/list';
    private ADD_BOOK_URL= this.BOOK_SERVICE_URL+'/books/add';
    private UPDATEBOOKQUANTITY_URL= this.BOOK_SERVICE_URL+'/books/updatequantity';
//http://35.202.22.39:8082/orders
    private ADDCART_URL= this.ORDER_SERVICE_URL+'/orders/cart/add';
    private LIST_CART_URL= this.ORDER_SERVICE_URL+'/orders/cart/list';
    private DELETE_CART_URL= this.ORDER_SERVICE_URL+'/orders/cart/delete';
    private CART_PAYMENT_URL= this.ORDER_SERVICE_URL+'/orders/cart/pay';
    private LIST_MYORDERS_URL= this.ORDER_SERVICE_URL+'/orders/myorders';
    private LIST_ALLORDERS_URL= this.ORDER_SERVICE_URL+'/orders/all';
    private UPDATE_DELIVERY_STATUS_URL= this.ORDER_SERVICE_URL+'/orders/update';
   
 
}