import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {HttpClient} from '@angular/common/http';
import { FormBuilder, FormGroup, FormControl,Validators } from '@angular/forms';
import { Globals } from './../../assets/globals';
declare var $: any;
import {DatePipe} from '@angular/common';
//import { parse } from 'path';
import { environment } from 'src/environments/environment';
declare var require: any;


@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss'],
  providers : [Globals,DatePipe]
})
export class PaymentComponent implements OnInit {
  userId: string;
  paymentType : string;
  paymentDate : any;
  books : string;
  constructor(private formBuilder: FormBuilder,private route: ActivatedRoute,private http : HttpClient,private router: Router,private globals:Globals,public datepipe: DatePipe)
  { }

  ngOnInit(): void {
    this.userId = sessionStorage.getItem('userId');
    console.log(this.userId);

    this.books = sessionStorage.getItem('books');
    console.log(this.books);

    let dateFormat = require('dateformat');
    let now = new Date();
    this.paymentDate = dateFormat(now, "dddd, mmmm dS, yyyy, h:MM:ss TT");
    console.log(this.paymentDate);
      
     
  }

  changePaymentType(event: any)
  {   
  this.paymentType = event.target.value;
  console.log(this.paymentType);
  }

  
paymentMethod(){
 // CART_PAYMENT_URL
 this.http.post(environment.orderPay_Url,
 {
     "emailid": `${this.userId}`,

     "paymenttype": `${this.paymentType}`,
     "paymentdate": `${this.paymentDate}`,

     "books": `${this.books}`
     

 })
 .subscribe(data =>
   {
if(data['messaage']= "success"){
  alert("Payment done successfully");
}else{
  alert("Payment not done");
}
  },
  error  =>{
  console.log(error);
  } );
}




}
  
