
import {Input, Component, Output, EventEmitter,OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {HttpClient} from '@angular/common/http';
import { FormBuilder, FormGroup, FormControl,Validators } from '@angular/forms';

import {environment} from './../../environments/environment';


declare var $: any;
@Component({
  selector: 'app-chome',
  templateUrl: './chome.component.html',
  styleUrls: ['./chome.component.scss']
})
export class ChomeComponent implements OnInit {
  model : any={};
  booksid : string;
  booklist: object [];
  userId :string; 
  //arrCase : object [];
  //avail : string [];

  //author : string [];

  quantity: any = 1;
  

 
 


  constructor(private formBuilder: FormBuilder,private route: ActivatedRoute,private http : HttpClient,private router: Router)
  { }

  ngOnInit(){
    this.listBook();
    this.userId = sessionStorage.getItem('userId');
   
    console.log(this.userId);
  }



  listBook() {
   // console.log(this.BOOK_LIST_URL);
    this.http.get(environment.bookList_Url)
    .subscribe( (data) => {
    console.log(data);
    
     this.booklist = data as object []; 

    // this.arrCase = data as object []; 
    // console.log(this.arrCase[0]['availability']);
     //this.avail = data as object [] ;
     //console.log(this.avail.length);
    //for(let i=0; i<=this.avail.length; i++)





     //this.avail = JSON.stringify(data);
     //console.log(this.avail);


    //this.booksid = JSON.stringify(data['bookid']);
    //console.log(data['bookid']);
    console.log(this.booklist);
    });
    }

    changeQuantity(event: any)
    {
         
    this.quantity = event.target.value;
    //console.log(this.quantity);
    }

    
    
addCartFunction(bookId: any,price: any)
{
  let userEmail = this.userId;
  const bookQuantity = this.quantity;
  console.log(bookId);
  //console.log(author);
  console.log(price);
  console.log(this.quantity);
  console.log(this.userId);
  this.http.post(environment.orderAdd_Url,
    {
     
      emailid: `${this.userId}`,
      bookid : `${bookId}`,
      quantity : this.quantity,
      price : price
	        
    })
        .subscribe(data =>
          {
            if(data['message']="success"){
              alert("items added to cart successully");
            }
            else{
              alert("items cannot be added");
            }
                  console.log("cart added sucessfully");
                
           },
            error  =>{
            console.log(error);
            } ); 


}



}
