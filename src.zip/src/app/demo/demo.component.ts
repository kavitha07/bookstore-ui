
import {Input, Component, Output, EventEmitter,OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {HttpClient} from '@angular/common/http';
import { FormBuilder, FormGroup, FormControl,Validators } from '@angular/forms';

import { Globals } from './../../assets/globals';
import {environment} from './../../environments/environment';

declare var $: any;

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.scss'],
  providers: [Globals]
  
})
export class DemoComponent implements OnInit {

  model : any={};
  name: string;
  email: string;
  role: string;
  Message: string;
  newRole: string;
  userId: string;
   
   // private LOGIN_URL= this.BOOK_SERVICE_URL+'/user/login';
  
  constructor(private formBuilder: FormBuilder,private route: ActivatedRoute,private http : HttpClient,private router: Router,private globals: Globals)
  { }
   

  ngOnInit() {
   //console.log(this.globals["LOGIN_URL"]);
  }

  onSubmit(){
 if(this.model.userId == null ||  this.model.password == null )
  {
    this.Message = "please enter the credentials";
     
 }
  else
  {
    this.http.post(environment.login_Url,
      {
          email: `${this.model.userId}`,
          password: `${this.model.password}`
          
      })
      .subscribe(data =>
        {
       // console.log("aREAL",data["role"]);
       // console.log("name",data["name"]);
         this.role = data["role"];
         this.name = data["name"];
         this.email = data["email"];
         
        // this.names = data["name"];
         
         console.log(this.email);
         console.log(this.name);
         console.log(this.role);
         if(this.role == "ADMIN")
        {
          this.router.navigate(['/mainhome']);
        }
        else
        {
          this.router.navigate(['/home']);
        }
       var nameid =this.name;
        var user= this.email;
        sessionStorage.setItem('userId',user);
        console.log('userId',user);
        
        sessionStorage.setItem('nameId',nameid);
        console.log('nameId',nameid);

 },  
          error  =>{
          console.log(error);
          } );    
      }
  }
  

}