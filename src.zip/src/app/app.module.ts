import { BrowserModule } from '@angular/platform-browser';
import { NgModule,ErrorHandler  } from '@angular/core';
import { ReactiveFormsModule,FormsModule }    from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { LayoutComponent } from './layout/layout.component';
import { HeaderComponent } from './layout/common/header/header.component';
import { FooterComponent } from './layout/common/footer/footer.component';
import { DashboardComponent } from './layout/dashboard/dashboard.component';



import { DemoComponent } from './demo/demo.component';
import { ChomeComponent } from './chome/chome.component';
import { MainhomeComponent } from './mainhome/mainhome.component';
import { SidebarComponent } from './layout/common/sidebar/sidebar.component';
import { CartComponent } from './cart/cart.component';
import { OrderComponent } from './order/order.component';
import { PaymentComponent } from './payment/payment.component';
import { AddbookComponent } from './addbook/addbook.component';
import { SignupComponent } from './signup/signup.component';
import { UserorderComponent } from './userorder/userorder.component';
//import {DataTableModule} from "angular-6-datatable";

@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    HeaderComponent,
    FooterComponent,
    DashboardComponent,
   
   
    DemoComponent,
    ChomeComponent,
    MainhomeComponent,
    SidebarComponent,
    CartComponent,
    OrderComponent,
    PaymentComponent,
    AddbookComponent,
    SignupComponent,
    UserorderComponent,
    
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    NgbModule
    
    
  ],
  providers: [{
      provide: ErrorHandler
    //  useClass: ErrorService,
     }],
  bootstrap: [AppComponent]
})
export class AppModule { }
