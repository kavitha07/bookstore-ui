import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {HttpClient} from '@angular/common/http';
import { FormBuilder, FormGroup, FormControl,Validators } from '@angular/forms';
import { Globals } from './../../assets/globals';
declare var $: any;
import {DatePipe} from '@angular/common';
//import { parse } from 'path';
//import { ConsoleReporter } from 'jasmine';
import { environment } from 'src/environments/environment';
//import { NgTableComponent, NgTableFilteringDirective, NgTablePagingDirective, NgTableSortingDirective } from 'ng2-table/ng2-table';
 //import { faCheck } from '@fortawesome/free-solid-svg-icons';
 declare var require: any;
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss'],
  providers: [Globals,DatePipe]
}) 
export class CartComponent implements OnInit {
userId: string;
price : any;
bookId =[];
bookIds =[];
quantitys =[];
quantity : any;
booksItem = [];
sum :any;
total : any;
cartList: any;
deleteItem : any;
paymentType : string;
  paymentDate : string;
time: any;
  today: number = Date.now();
  payments : boolean;
  ///date and time

  //todayNumber: number = Date.now();
  //todayDate : Date = new Date();
  //todayString : string = new Date().toDateString();
  //todayISOString : string = new Date().toISOString();

  constructor(private formBuilder: FormBuilder,private route: ActivatedRoute,private http : HttpClient,private router: Router,private globals:Globals,public datepipe: DatePipe)
  { }
  ngOnInit() {
    this.payments = false;
    this.userId = sessionStorage.getItem('userId');
    console.log(this.userId);
    this.total = 0;
    this.cartItems();

    $( "#one" ).show();
    $( "#two" ).hide();
$("#oneButton").click(function(){
     $("#two").show();
     $("#one").hide();
    });
    //let dateFormat = require('dateformat');
    //let now = new Date();
    //this.paymentDate = dateFormat(now, "dddd, mmmm dS, yyyy, h:MM:ss TT");
    //console.log(this.paymentDate);
//console.log(this.time);
let dateFormat = require('dateformat');
let now = new Date();
this.paymentDate = dateFormat(now,"mm/d/yy HH:MM:ss"); 
console.log(this.paymentDate);

  }
  

 cartItems()
  {
    
    this.http.post(environment.orderList_Url,
    {
        "emailid": `${this.userId}`
    })
    .subscribe(data =>
      {
        this.cartList = data;
        console.log(this.cartList);
//bookid
this.bookIds =data as object[];
for(let i=0;i<=this.bookIds.length; i++){
 // console.log(this.bookIds[i]['bookid']);
  this.bookId = this.bookIds[i]['bookid'];
  this.quantity = this.bookIds[i]['quantity'];
  this.total = this.total + this.bookIds[i]['price'];
  console.log(this.total);
  console.log(this.bookId);
  console.log(this.quantity);

  var bookObj = {};
  let key1 = "bookId";
  let key2 = "quantity";
  bookObj[key1] = `${this.bookId}`;
  bookObj[key2] = this.quantity;

  console.log("Book Object: ",bookObj);
  this.booksItem.push(bookObj);
  console.log(this.booksItem);
 

} 



      },
      error  =>{
      console.log(error);
      } );
  }

//deleteitems
deleteItems(orderId: any){
  console.log(this.userId);
  console.log(orderId);
  this.http.post(environment.orderDelete_Url,
  {//
      "emailid": `${this.userId}`,
      "orderid" :`${orderId}`
  })
  .subscribe(data =>
    {
      console.log(data);
      if(data['message']="success"){
        alert("Item Deleted Successully");
        this.cartItems();
      }
      else{
        alert("Item Cannot be Deleted");
      }

    },
    error  =>{
    console.log(error);
    } );
}


payment(){
  this.payments = true;
}



//payment
changePaymentType(event: any)
{   
this.paymentType = event.target.value;
console.log(this.paymentType); 
}

paymentMethod(){
  console.log(this.paymentDate);
  console.log(this.booksItem);

this.http.post(environment.orderPay_Url,
{
   "emailid": `${this.userId}`,
   "paymenttype": `${this.paymentType}`,
   "paymentdate": `${this.paymentDate}`,
   "books": this.booksItem
})
.subscribe(data =>
 {

if(data['messaage']= "success"){

  console.log("sucess");
alert("Payment done successfully");
this.router.navigate(['/userorder']);
        
}else{
alert("Payment not done");
}
},
error  =>{
console.log(error);
} );
}
   


}
