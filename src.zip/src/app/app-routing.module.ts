import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LayoutComponent } from './layout/layout.component';
import { DashboardComponent } from './layout/dashboard/dashboard.component';


//import { HomeComponent } from './home/home.component';
import { DemoComponent } from './demo/demo.component';
import { SignupComponent } from './signup/signup.component';
import { ChomeComponent } from './chome/chome.component';
import { OrderComponent } from './order/order.component';
import { UserorderComponent } from './userorder/userorder.component';
import { CartComponent } from './cart/cart.component';
import { PaymentComponent } from './payment/payment.component';
import { MainhomeComponent } from './mainhome/mainhome.component';
import { AddbookComponent } from './addbook/addbook.component';

const routes: Routes = [
  { path: 'login', component: DemoComponent},
  { path: 'signup', component: SignupComponent},
  { path: 'allorder', component: OrderComponent},
  { path: 'userorder', component: UserorderComponent},
  { path: 'cart', component: CartComponent},
  { path: 'payment', component: PaymentComponent},
  { path: 'mainhome', component: MainhomeComponent},
  { path: 'addbook', component: AddbookComponent},
 
  {
    path: '',
    component: LayoutComponent,
    //canActivate: [AuthGuard],
    children: [
      { path: '', component: DashboardComponent },
      { path: 'home', component: ChomeComponent},
    ]
  },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
