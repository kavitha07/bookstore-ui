import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {HttpClient} from '@angular/common/http';
import { FormBuilder, FormGroup, FormControl,Validators } from '@angular/forms';
import { Globals } from './../../assets/globals';
import { environment } from 'src/environments/environment';

declare var $: any;

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss'],
  providers: [Globals]
})
export class OrderComponent implements OnInit {

  userId: string;
  ordersList: any;
  deliveryStatus: string;
  orderId: string;

  constructor(private formBuilder: FormBuilder,private route: ActivatedRoute,private http : HttpClient,private router: Router,private globals:Globals)
  { }

  ngOnInit() {

    this.userId = sessionStorage.getItem('userId');
    console.log(this.userId);

    this.allOrders();

  }

  allOrders()
  {
    this.http.post(environment.orderAll_Url,
    {
        "emailid": `${this.userId}`
    })
    .subscribe(data =>
      {
        this.ordersList = data;
        console.log(this.ordersList);
      },
      error  =>{
      console.log(error);
      } );
  }

  getOrderID(orderid:any)
  {
    this.orderId = orderid;
    console.log(this.orderId);
  }

  changeStatus(event: any)
  {
  this.deliveryStatus = event.target.value;
  console.log(this.deliveryStatus);
  }

  updateStatus()
  {
    this.http.post(environment.orderUpdate_Url,
    {
      "emailid": `${this.userId}`,
      "orderid": `${this.orderId}`,
      "deliverystatus": `${this.deliveryStatus}`
    })
    .subscribe(data =>
      {
        console.log("Delivery status updated");
        this.allOrders();
      },
      error  =>{
      console.log(error);
      } );
  }


}
