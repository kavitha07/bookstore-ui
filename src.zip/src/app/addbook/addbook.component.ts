import {Input, Component, Output, EventEmitter,OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {HttpClient} from '@angular/common/http';
import { FormBuilder, FormGroup, FormControl,Validators } from '@angular/forms';
import { Globals } from './../../assets/globals';
import { environment } from 'src/environments/environment';
//import { threadId } from 'worker_threads';

declare var $: any;

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.scss'],
  providers:[Globals]
})
export class AddbookComponent implements OnInit {

 userId: string;
 model : any={};
  bookName: string;
  author: string; 
  category: string;
  price: number;
  availability: number;

  constructor(private formBuilder: FormBuilder,private route: ActivatedRoute,private http : HttpClient,private router: Router,private globals:Globals)
  { 
    
  }

  
  ngOnInit() {
    this.userId = sessionStorage.getItem('userId');
    //sessionStorage.getItem(user);
    console.log(this.userId);
   // console.log(Order_Url);

  } 


  addBook(){
    
    console.log(`${this.userId}`);
    console.log(this.model.bookName);
    console.log(this.model.author);
    console.log(this.model.category);
    console.log(this.model.price);
    console.log(this.model.availability);

    this.http.post(environment.bookAdd_Url,
    { 
      email : `${this.userId}`,
      bookname : `${this.model.bookName}`,
      author : `${this.model.author}`,
      category : `${this.model.category}`,
      price : this.model.price,
     availability : this.model.availability
   })
  .subscribe(data =>
    {
      console.log("Book added sucessfully");
    },
    error  =>{
    console.log(error);
    } );    
}


  }


