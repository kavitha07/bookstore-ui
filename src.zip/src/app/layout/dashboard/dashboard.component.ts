import { Component, OnInit, AfterViewInit} from '@angular/core';
//import { SpinnerService,AlertService } from '../../_services';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  constructor() { 
    
  }

  ngOnInit(): void {
   
  }

  

  AfterViewInit(){
   
  }

}
