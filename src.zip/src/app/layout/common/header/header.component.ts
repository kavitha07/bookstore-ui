import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  userId: string;
  nameId : string;
  constructor() { }

  ngOnInit(): void {
    this.userId = sessionStorage.getItem('userId');
   
    console.log(this.userId);
    this.nameId = sessionStorage.getItem('nameId');
    console.log(this.nameId);
  }

}
