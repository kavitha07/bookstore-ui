import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

  public show:boolean;
  public classificationMenu: Array<any>;
  public clusteringMenu: Array<any>;
  public regressionMenu: Array<any>;

  constructor() { }

  ngOnInit(): void {
    this.classificationMenu = [
      { name: 'Decision Tree', path: './home', children: [] },
      { name: 'Naive Bavesian', path: './home', children: [] },
      { name: 'Support Vector Machines', path: './home', children: [] },
      { name: 'Random Forest', path: './home', children: [] },
    ];

    this.clusteringMenu = [
      { name: 'K Means', path: './home', children: [] },
      { name: 'Fuzzy K means', path: './home', children: [] },
      { name: 'Hierarchical', path: './home', children: [] }
    ];
    
     this.regressionMenu = [
      { name: 'Linear Regression', path: './home', children: [] },
      { name: 'Support Vectors', path: './home', children: [] },
      { name: 'Logistic Regression', path: './home', children: [] }
    ]
  }

}
