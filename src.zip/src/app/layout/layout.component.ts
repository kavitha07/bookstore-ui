import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
//import { SpinnerService, AlertService } from '../_services';


@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})

export class LayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
   
  }

  ngOnDestroy() {
   // this.subscription.unsubscribe();
  }

}
