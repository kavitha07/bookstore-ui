import {Input, Component, Output, EventEmitter,OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {HttpClient} from '@angular/common/http';
import { FormBuilder, FormGroup, FormControl,Validators } from '@angular/forms';
import {environment} from './../../environments/environment';


declare var $: any;
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  model : any={};
  name : string;
  password : any;
  email : any;
  mobile : any;
  city : any;
  state: any;
  address: string;
  pincode: number; 
  Message: string; 
  private BOOK_IP_ADDRESS ='35.202.22.39';
  private BOOK_PORT ='8080';
  private BOOK_SERVICE_URL='http://'+this.BOOK_IP_ADDRESS+':'+this.BOOK_PORT;
  private SIGNUP_URL = this.BOOK_SERVICE_URL+'/user/add';
//http://35.202.22.39:8080/user/add
private signupUrl="http://35.202.22.39/user/add";

constructor(private formBuilder: FormBuilder,private route: ActivatedRoute,private http : HttpClient,private router: Router)
{ }
  ngOnInit() {
  }
addSignup(){
  
  if(this.model.email == null ||  this.model.name == null ||  this.model.password == null ||  this.model.mobile == null ||  this.model.address == null ||  this.model.city == null ||  this.model.state == null ||  this.model.pincode == null )
  {
    this.Message = "please enter the credentials";
     
 }
  else
  {
  this.http.post(environment.signup_Url,
    {
      email:`${this.model.email}`,
      name: `${this.model.name}`,
        password: `${this.model.password}`,
        mobile: `${this.model.mobile}`,
        address: `${this.model.address}`,
        city: `${this.model.city}`,
        state: `${this.model.state}`,
        pincode: `${this.model.pincode}`
        
    })
    .subscribe(data =>
      {
        alert("User Added");
        this.router.navigate(['/login']);
       
      },
      error  =>{
      console.log(error);
      } );    
  }
}

}
