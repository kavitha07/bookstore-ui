import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {HttpClient} from '@angular/common/http';
import { FormBuilder, FormGroup, FormControl,Validators } from '@angular/forms';
import { Globals } from './../../assets/globals';
import { environment } from 'src/environments/environment';

declare var $: any;
@Component({
  selector: 'app-userorder',
  templateUrl: './userorder.component.html',
  styleUrls: ['./userorder.component.scss'],
  providers: [Globals] 
})
export class UserorderComponent implements OnInit {
  userId: string;
  myOrderList: any;
  constructor(private formBuilder: FormBuilder,private route: ActivatedRoute,private http : HttpClient,private router: Router,private globals:Globals)
  { }

  ngOnInit(): void {
    this.userId = sessionStorage.getItem('userId');
    console.log(this.userId);
    this.myOrders();

     
  } 
  myOrders()
  {
    this.http.post(environment.orderMyoders_Url,
    {
        "emailid": `${this.userId}`
    })
    .subscribe(data =>
      {
        this.myOrderList = data;
        console.log(this.myOrderList);

     
       //console.log('jhgjuyuiy');

      },
      error  =>{
      console.log(error);
      } );
  }

}
